<?php
session_start();
include('dbcon.php');
if(isset($_POST['update_contact']))

{
    $first_name=$_POST['first_name'];
    $last_name=$_POST['last_name'];
    $Email=$_POST['email'];
    $Phone=$_POST['phone'];

    $postData = [
'fname'->$first_name,
'lname'->$last_name,
'email'->$email,
'phone'->$phone,

];
}
if(isset($_POST['save_contact']))
{
    $first_name=$_POST['first_name'];
    $last_name=$_POST['last_name'];
    $Email=$_POST['email'];
    $Phone=$_POST['phone'];

    $postData = [
'fname'=>$first_name,
'lname'=>$last_name,
'email'=>$Email,
'phone'=>$Phone,

];
$ref_table="contacts";
$postRef_result = $database->getReference($ref_table)->push($postData);
if($postRef_result)
{
    $_SESSION['status']='contact added Successfully';
    header('location:index.php');
}
else
{
    $_SESSION['status']='contact not Added';
    header('location:index.php');
}

}

?>